packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 41 42 43 44 45 46 47 61 62 63 64 65 66 67 68 69 6a 6b 6c 6d 6e' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 47 41 42 43 44 45 46 67 61 62 63 64 65 66 6e 68 69 6a 6b 6c 6d' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 46 47 41 42 43 44 45 66 67 61 62 63 64 65 6d 6e 68 69 6a 6b 6c' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 45 46 47 41 42 43 44 65 66 67 61 62 63 64 6c 6d 6e 68 69 6a 6b' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 44 45 46 47 41 42 43 64 65 66 67 61 62 63 6b 6c 6d 6e 68 69 6a' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 43 44 45 46 47 41 42 63 64 65 66 67 61 62 6a 6b 6c 6d 6e 68 69' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 42 43 44 45 46 47 41 62 63 64 65 66 67 61 69 6a 6b 6c 6d 6e 68' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 61 62 63 64 65 66 67 41 42 43 44 45 46 47 68 69 6a 6b 6c 6d 6e' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 67 61 62 63 64 65 66 47 41 42 43 44 45 46 6e 68 69 6a 6b 6c 6d' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 66 67 61 62 63 64 65 46 47 41 42 43 44 45 6d 6e 68 69 6a 6b 6c' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 65 66 67 61 62 63 64 45 46 47 41 42 43 44 6c 6d 6e 68 69 6a 6b' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 64 65 66 67 61 62 63 44 45 46 47 41 42 43 6b 6c 6d 6e 68 69 6a' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 63 64 65 66 67 61 62 43 44 45 46 47 41 42 6a 6b 6c 6d 6e 68 69' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 62 63 64 65 66 67 61 42 43 44 45 46 47 41 69 6a 6b 6c 6d 6e 68' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 41 42 43 44 45 46 47 61 62 63 64 65 66 67 48 49 4a 4b 4c 4d 4e' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 47 41 42 43 44 45 46 67 61 62 63 64 65 66 4e 48 49 4a 4b 4c 4d' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 57 6f 72 6c 64 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 46 47 41 42 43 44 45 66 67 61 62 63 64 65 4d 4e 48 49 4a 4b 4c' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 45 46 47 41 42 43 44 65 66 67 61 62 63 64 4c 4d 4e 48 49 4a 4b' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 44 45 46 47 41 42 43 64 65 66 67 61 62 63 4b 4c 4d 4e 48 49 4a' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 43 44 45 46 47 41 42 63 64 65 66 67 61 62 4a 4b 4c 4d 4e 48 49' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 57 6f 72 6c 64 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 42 43 44 45 46 47 41 62 63 64 65 66 67 61 49 4a 4b 4c 4d 4e 48' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 61 62 63 64 65 66 67 41 42 43 44 45 46 47 48 49 4a 4b 4c 4d 4e' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 48 65 6c 6c 6f 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 67 61 62 63 64 65 66 47 41 42 43 44 45 46 4e 48 49 4a 4b 4c 4d' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 66 67 61 62 63 64 65 46 47 41 42 43 44 45 4d 4e 48 49 4a 4b 4c' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 65 66 67 61 62 63 64 45 46 47 41 42 43 44 4c 4d 4e 48 49 4a 4b' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 48 65 6c 6c 6f 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 64 65 66 67 61 62 63 44 45 46 47 41 42 43 4b 4c 4d 4e 48 49 4a' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 63 64 65 66 67 61 62 43 44 45 46 47 41 42 4a 4b 4c 4d 4e 48 49' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 62 63 64 65 66 67 61 42 43 44 45 46 47 41 49 4a 4b 4c 4d 4e 48' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64 48 65 6c 6c 6f'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 41 42 43 44 45 46 47 61 62 63 64 65 66 67 68 69 6a 6b 6c 6d 6e' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 47 41 42 43 44 45 46 67 61 62 63 64 65 66 6e 68 69 6a 6b 6c 6d' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 46 47 41 42 43 44 45 66 67 61 62 63 64 65 6d 6e 68 69 6a 6b 6c' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 45 46 47 41 42 43 44 65 66 67 61 62 63 64 6c 6d 6e 68 69 6a 6b' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 44 45 46 47 41 42 43 64 65 66 67 61 62 63 6b 6c 6d 6e 68 69 6a' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 43 44 45 46 47 41 42 63 64 65 66 67 61 62 6a 6b 6c 6d 6e 68 69' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 42 43 44 45 46 47 41 62 63 64 65 66 67 61 69 6a 6b 6c 6d 6e 68' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 61 62 63 64 65 66 67 41 42 43 44 45 46 47 68 69 6a 6b 6c 6d 6e' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 67 61 62 63 64 65 66 47 41 42 43 44 45 46 6e 68 69 6a 6b 6c 6d' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 66 67 61 62 63 64 65 46 47 41 42 43 44 45 6d 6e 68 69 6a 6b 6c' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 65 66 67 61 62 63 64 45 46 47 41 42 43 44 6c 6d 6e 68 69 6a 6b' -sR -d 204.57.1.176
#packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 64 65 66 67 61 62 63 44 45 46 47 41 42 43 6b 6c 6d 6e 68 69 6a' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 63 64 65 66 67 61 62 43 44 45 46 47 41 42 6a 6b 6c 6d 6e 68 69' -sR -d 204.57.1.176
packit -m inject -t tcp -i eth0 -c 2 -b 1 -p '0x 62 63 64 65 66 67 61 42 43 44 45 46 47 41 69 6a 6b 6c 6d 6e 68' -sR -d 204.57.1.176
packit -t tcp -m inject -sR -d 204.57.1.176 -c 1 -b 1 -p '0x 48 65 6c 6c 6f 4d 61 6e 64 72 69 76 61 66 61 63 65 62 6f 6f 6b 57 6f 72 6c 64'

  
